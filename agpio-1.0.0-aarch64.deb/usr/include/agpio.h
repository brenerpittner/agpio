#ifndef AGPIO_H
#define AGPIO_H

#define INPUT "in"
#define OUTPUT "out"
#define LOW "0"
#define HIGH "1"
#define PIN22 157
#define PIN36 132

int version();
void pinMode(int pin, const char* direction); //const char* pin
void digitalWrite(int pin, const char* value);
int digitalRead(int pin);
void delay(int t);
void status(int status);
void createPin(int pin);
void deletePin(int pin);
void setDirection(int pin, const char* direction);
void listGPIO();
#endif
